El marketplace seleccionado como candidato sera una veterinaria. Probablemente la parte a desarrollar sea el pet shop.

La veterinaria en si tiene una amplia gama de productos que podria ser categorizados de distintas maneras, ya sea por animales (canino, felino, peces) y sub categorias asociadas a distintos tipos de productos (alimentos, remedios, jugetes, higiene) o marcas (purina, royal caning, eukanuba, etc)
La gama de productos que comercializa una veterinaria es muy amplia y puede crecer aun mas dependiendo de la cantidad de distintos tipos de animales que reciba.

Tambien puede brindar cirugia general, laboratorio, internacion, contar con un sistema de turnos para este tipo de actividades. Registro de pacientes, historia clinica de las mismas, etc.

Siendo que el alcance es bastante amplio, se sugiere orientar el desarrollo hacia la actividad de petshot, y orientar el segmento hacia productos para mascotas de tipo canino y felino. 

El canal de distribucion para estos productos sera un ecommerce.

<b>Descripción del equipo:</b><br>
//////////////////////////


<b>Ezequiel Coletta:</b> Licenciado en Sistemas de Informacion. MBA en Gestión Estratégica de Técnologia y Sistemas de Información. Arquitecto de Infraestructuras de TI. Ayudante ad-honorem en UBA - Catedra Actuación Profesional del Licenciado en Sistemas de Información.

<b>Sebastian Gregori:</b> Ingeniero en Electrónica y Comunicaciones.


<b>Sitios de referencia:</b><br>
//////////////////////////

1- https://www.veterinariaalem.com/ (Veterinaria Alem) <br>
2- https://www.centropet.com/ (Centropet) <br>
3- https://tienda.faunatikos.com.ar/ (Faunatikos) <br>
4- https://www.mascotasdeloeste.com.ar/ (Mascotas del Oeste) <br>
5- https://www.puppis.com.ar/ (Artículos para mascotas) <br>

<b>Tablero de Trello Asociado::</b><br>
//////////////////////////

https://trello.com/b/yKNA07xj/dh-proyecto-veterinaria

Nivel de acceso: 

Lectura (Público) 
Edicion (Solo miembros del equipo) 
